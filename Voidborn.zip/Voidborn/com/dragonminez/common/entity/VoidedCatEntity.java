package com.dragonminez.common.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class VoidedCatEntity extends PathfinderMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public VoidedCatEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    // Atributos Base: Velocidade estilo Toji e 50k de Vida padrão
    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 50000.0D)        // 50.000 HP base (contra mobs)
                .add(Attributes.MOVEMENT_SPEED, 0.75D)        // Velocidade insana (Toji Fushiguro)
                .add(Attributes.ARMOR, 50.0D)                 // 50 de Armadura
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);  // Imune a repulsão
    }

    // Adaptação dinâmica de Vida
    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide()) {
            // Se o alvo atual for um Jogador
            if (this.getTarget() instanceof Player player) {
                double playerMaxHp = player.getMaxHealth();
                
                // Adapta a vida máxima da entidade para a vida do jogador
                if (this.getMaxHealth() != playerMaxHp) {
                    this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(playerMaxHp);
                    if (this.getHealth() > playerMaxHp) {
                        this.setHealth((float) playerMaxHp);
                    }
                }
            } else {
                // Se estiver sem alvo ou atacando outros mobs, mantém os 50k de HP
                if (this.getMaxHealth() != 50000.0D) {
                    this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(50000.0D);
                }
            }
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 0, event -> {
            if (event.isMoving()) {
                return event.setAndContinue(RawAnimation.begin().thenLoop("walk"));
            }
            return event.setAndContinue(RawAnimation.begin().thenLoop("idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
