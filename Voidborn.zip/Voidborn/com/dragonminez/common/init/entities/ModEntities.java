package com.dragonminez.common.init.entities;

import com.dragonminez.common.entity.VoidedCatEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registrations.DeferredRegister;
import net.minecraftforge.registrations.ForgeRegistries;
import net.minecraftforge.registrations.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = 
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "voidborn");

    public static final RegistryObject<EntityType<VoidedCatEntity>> VOIDED_CAT = 
        ENTITIES.register("voided_cat", () -> 
            EntityType.Builder.of(VoidedCatEntity::new, MobCategory.CREATURE)
                .sized(0.6f, 0.7f)
                .build("voided_cat")
        );
}
