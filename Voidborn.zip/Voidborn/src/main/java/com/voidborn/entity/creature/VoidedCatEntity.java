package com.voidborn.entity.creature;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;


public class VoidedCatEntity extends Monster implements GeoEntity {


    private final AnimatableInstanceCache cache =
            GeckoLibUtil.createInstanceCache(this);


    public VoidedCatEntity(
            EntityType<? extends Monster> type,
            Level level
    ) {
        super(type, level);
    }


    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {

    }


    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

}