package com.voidborn.client.model;

import com.voidborn.entity.creature.VoidedCatEntity;

import software.bernie.geckolib.model.GeoModel;

public class VoidedCatModel extends GeoModel<VoidedCatEntity> {

    @Override
    public net.minecraft.resources.ResourceLocation getModelResource(VoidedCatEntity entity) {
        return new net.minecraft.resources.ResourceLocation(
                "voidborn",
                "geo/voided_cat.geo.json"
        );
    }

    @Override
    public net.minecraft.resources.ResourceLocation getTextureResource(VoidedCatEntity entity) {
        return new net.minecraft.resources.ResourceLocation(
                "voidborn",
                "textures/entity/voided_cat.png"
        );
    }

    @Override
    public net.minecraft.resources.ResourceLocation getAnimationResource(VoidedCatEntity entity) {
        return new net.minecraft.resources.ResourceLocation(
                "voidborn",
                "animations/voided_cat.animation.json"
        );
    }
}