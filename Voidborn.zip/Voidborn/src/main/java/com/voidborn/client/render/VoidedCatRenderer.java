package com.voidborn.client.render;

import com.voidborn.client.model.VoidedCatModel;
import com.voidborn.entity.creature.VoidedCatEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class VoidedCatRenderer extends GeoEntityRenderer<VoidedCatEntity> {

    public VoidedCatRenderer(EntityRendererProvider.Context context) {
        super(context, new VoidedCatModel());
    }

}